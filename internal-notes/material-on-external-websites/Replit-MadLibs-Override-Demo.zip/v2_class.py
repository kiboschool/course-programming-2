
template = [
  'Everything changed when the band "mega ',
  'NOUN',
  '" released their first album in the year ',
  'NUMBER',
  '. The emotion was being channeled through rock songs full of ',
  'NOUN',
  ', and the otherworldly vocals powerfully ',
  'VERB',
  '.'
]

class MadLibsEngine():
  def play(self, template):
    output = ''
    for item in template:
      if item == 'NOUN':
        output += self.get_noun()
      elif item == 'VERB':
        output += self.get_verb()
      elif item == 'NUMBER':
        output += str(self.get_number())
      else:
        output += item

    return output

  def get_noun(self):
    return input('Please type a noun:')

  def get_verb(self):
    return input('Please type a verb:')

  def get_number(self):
    return input('Please type a number:')

output = MadLibsGame().play(template)
print(output)
