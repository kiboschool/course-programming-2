
import random

template = [
  'Everything changed when the band "mega ',
  'NOUN',
  '" released their first album in the year ',
  'NUMBER',
  '. The emotion was being channeled through rock songs full of ',
  'NOUN',
  ', and the otherworldly vocals powerfully ',
  'VERB',
  '.'
]


class MadLibsEngineParent():
  def play(self, template):
    output = ''
    for item in template:
      if item == 'NOUN':
        output += self.get_noun()
      elif item == 'VERB':
        output += self.get_verb()
      elif item == 'NUMBER':
        output += str(self.get_number())
      else:
        output += item

    return output

  def get_noun(self):
    pass
    
  def get_verb(self):
    pass
    
  def get_number(self):
    pass
    


class MadLibsEngineInteractive(MadLibsEngineParent):
  def get_noun(self):
    return input('Please type a noun:')
    
  def get_verb(self):
    return input('Please type a verb:')
    
  def get_number(self):
    return input('Please type a number:')
    

class MadLibsEngineRandom(MadLibsEngineParent):
  def __init__(self):
    self.nouns = (  
      'apple,arm,banana,bike,bird,book,chin,clam,clover,club,corn,' +
      'flower,fog,game,heat,hill,home,joke,juice,kite,lake').split(',')
    self.verbs = ('added,dropped,knitted,obeyed,scattered,visited,'+
      'allowed,ended,hugged,jumped,named,reached,landed,' +
      'opened,stayed,walked,baked,escaped,imagined').split(',')
      
  def get_noun(self):
    return random.choice(self.nouns)
  
  def get_verb(self):
    return random.choice(self.verbs)
    
  def get_number(self):
    return random.randint(1, 3000)


output = MadLibsRandom().play(template)
print(output)
