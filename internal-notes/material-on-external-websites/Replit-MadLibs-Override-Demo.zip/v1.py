
template = [
  'Everything changed when the band "mega ',
  'NOUN',
  '" released their first album in the year ',
  'NUMBER',
  '. The emotion was being channeled through rock songs full of ',
  'NOUN',
  ', and the otherworldly vocals powerfully ',
  'VERB',
  '.'
]

def play():
    output = ''
    for item in template:
      if item == 'NOUN':
        output += get_noun()
      elif item == 'VERB':
        output += get_verb()
      elif item == 'NUMBER':
        output += str(get_number())
      else:
        output += item

    return output

def get_noun():
    return input('Please type a noun:')

def get_verb():
    return input('Please type a verb:')

def get_number():
    return input('Please type a number:')

output = play()
print(output)
