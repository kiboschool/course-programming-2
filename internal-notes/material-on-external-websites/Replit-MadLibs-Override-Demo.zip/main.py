
print()
print()
print()
print()
print()
print('Please open the replit Shell on the right,')
print('and run a script by typing something like')
print('python v1.py')
