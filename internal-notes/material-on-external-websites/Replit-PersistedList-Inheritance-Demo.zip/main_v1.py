import os

class PersistedList:
  def __init__(self, filename):
    self.filename = filename
    self.internal_list = []
    
    if os.path.exists(filename):
      with open(self.filename, 'r') as f:
        file_contents = f.read()
        if file_contents:
          self.internal_list = file_contents.split('\n')

  def append(self, incoming_string):
    self.internal_list.append(incoming_string)
    with open(self.filename, 'w') as f:
      new_file_contents = '\n'.join(self.internal_list)
      f.write(new_file_contents)
    
  def insert(self, position, incoming_string):
    self.internal_list.insert(position, incoming_string)
    with open(self.filename, 'w') as f:
      new_file_contents = '\n'.join(self.internal_list)
      f.write(new_file_contents)
  
  def get_last_item(self):
    length = len(self.internal_list)
    return self.internal_list[length - 1]
  
  def get_item_at(self, position):
    return self.internal_list[position]
  
  def set_item_at(self, position, incoming_string):
    self.internal_list[position] = incoming_string
    with open(self.filename, 'w') as f:
      new_file_contents = '\n'.join(self.internal_list)
      f.write(new_file_contents)

if __name__ == '__main__':
  # reset output
  if os.path.exists('persisted.txt'):
    os.unlink('persisted.txt')
    
  # let's try it!
  the_list = PersistedList('persisted.txt')
  the_list.append('d')
  
  # load another instance, it will have our new item 
  other = PersistedList('persisted.txt')
  print(other.get_last_item())
